import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  city: any;
  username: string | undefined;
  password: string | undefined;
  userId: string | undefined;
  error: string | undefined;
  url: string | undefined;
  cid: string | null = null;
  urlnew: string | undefined;
  cart: string | undefined;

  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.paramMap.subscribe(params => { this.city = params.get('city') });
    localStorage.setItem("city", this.city);
    console.log(this.city);
  }

  ngOnInit() {

    localStorage.setItem("city", this.city);
    console.log("my city " + this.city)
    this.city = localStorage.getItem('city');
    let url = "http://localhost:8888/showallproduct?city=" + this.city;
    fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data)
      })

    this.cid = localStorage.getItem('id');
    if (this.cid != undefined) {
      this.urlnew = 'http://localhost:8888/findcustomerid/' + this.cid;
      fetch(this.urlnew)
        .then(res => res.json())
        .then(data => {
          this.username = data[0].customername;
          this.city = localStorage.getItem("city");
        })
    }
    else {
      this.username = 'noLoggedInUser'
    }

    let url3 = "http://localhost:8888/viewcart/" + this.cid;
    fetch(url3, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data);
        if (data[0] != null) {
          this.cart = 'items';
        }
        else {
          this.cart = 'noitems';
        }
      })

  }

  handleClick(city: any) {
    localStorage.setItem("city", city);
    console.log(city);
    let url = "http://localhost:8888/showallproduct?city=" + city;
    fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data)
      })
  }

  logout() {
    alert("You have logged out from this session!");
    localStorage.removeItem('token');
    localStorage.removeItem('id');
    window.location.reload();
  }

}
