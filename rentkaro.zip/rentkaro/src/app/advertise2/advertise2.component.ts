import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertise2',
  templateUrl: './advertise2.component.html',
  styleUrls: ['./advertise2.component.css']
})
export class Advertise2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
