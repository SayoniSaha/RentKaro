import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  username:string | undefined;
  userid:string | undefined;
  key:'123456$#@$^@1ERF' | undefined;
  _url:any;

  constructor() {
    
  }
   

  ngOnInit(){
    
    this.loggedInUser();
  }

  loggedInUser(){
    this.userid =localStorage.getItem('id')!;
    if(this.userid!=undefined){ 
    this._url = `http://localhost:8888/findcustomerid/`+this.userid;
    fetch(this._url)
    .then(res=>res.json())
    .then(data=>{
      this.username=data[0].customername;      
    })
  }
  else{
   this.username='noLoggedInUser'
  }
}

}
