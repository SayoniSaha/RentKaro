import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-productcatalogue',
  templateUrl: './productcatalogue.component.html',
  styleUrls: ['./productcatalogue.component.css']
})
export class ProductcatalogueComponent implements OnInit {
  @ViewChild('openModal', { static: false }) openModal!: ElementRef;
  @ViewChild('closeModal', { static: false }) closeModal!: ElementRef;
  city: any;
  category: any;
  List: any
  username: string | undefined;
  userid: string | undefined;
  key: '123456$#@$^@1ERF' | undefined;
  _url: any;
  cid: any;
  cart: string | undefined;
  addurl: any;
  cartlist: any;

  productList: any[] = [];

  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe(params => { this.category = params['category'], this.city = params['city'] });
  }

  ngOnInit() {
    this.loggedInUser();
    this.city = localStorage.getItem('city');
    let url = "http://localhost:8888/showallproduct?category=" + this.category + "&city=" + this.city;
    this.fetchProductData(this.category, this.city);
    fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data)
        this.List = data;
      })

    this.cid = localStorage.getItem('id');
    let url3 = "http://localhost:8888/viewcart/" + this.cid;
    fetch(url3, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data);
        this.cartlist = data;
        if (data[0] != null) {
          this.cart = 'items';
        }
        else {
          this.cart = 'noitems';
        }
      })

  }

  fetchProductData(category: string, city: string) {
    let url = "http://localhost:8888/showallproduct?category=" + this.category + "&city=" + city;
    fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data);
        this.productList = data;
      });
  }

  handleClick(city: any) {
    localStorage.setItem("city", city);
    let url = "http://localhost:8888/showallproduct?category=" + this.category + "&city=" + city;
    fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data)
        this.List = data;
      })
    this.fetchProductData(this.category, city); // Fetch product data for the selected city
  }
  handleClick2(category: any) {
    localStorage.setItem("city", this.city);
    let url = "http://localhost:8888/showallproduct?category=" + category + "&city=" + this.city;
    fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data)
        this.List = data;
      })
    this.fetchProductData(category, this.city); // Fetch product data for the selected category
  }

  loggedInUser() {
    this.userid = localStorage.getItem('id')!;
    if (this.userid != undefined) {
      this._url = 'http://localhost:8888/findcustomerid/' + this.userid;
      fetch(this._url)
        .then(res => res.json())
        .then(data => {
          this.username = data[0].customername;
        })
    }
    else {
      this.username = 'noLoggedInUser'
    }
  }

  addtocart(pid: any) {
    console.log("bought the product", pid);






    this.cid = localStorage.getItem('id');
    let buy = "yes";
    //for(let i of Object.keys(this.cartlist)){
    for (let i of this.cartlist) {
      if (i.productid == pid) {
        console.log("no")
        buy = "no";
      }
    }
    if (this.cid !== undefined && buy == "yes") {
      let products = [];
      if (localStorage.getItem('products')) {
        products = JSON.parse(localStorage.getItem('products')!);
      }
      products.push({ 'productId': pid });
      localStorage.setItem('products', JSON.stringify(products));
      let addurl = "http://localhost:8888/mycart/" + pid + "/" + this.cid;
      fetch(addurl, {
        method: "GET",
        headers: {
          "content-type": "application/json"
        }
      })
        .then(res => res.text())
        .then(data => {
          console.log(data);
          if (data != null) {
            this.openModal.nativeElement.click();
          }
          window.location.reload();
        })
    }
    else {
      this.closeModal.nativeElement.click();
    }
  }


  logout() {
    alert("Successfully logged out from this session")
    localStorage.removeItem('token');
    localStorage.removeItem('id');
    window.location.reload();
  }

}
