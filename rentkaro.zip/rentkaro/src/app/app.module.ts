import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NgxImageZoomModule } from 'ngx-image-zoom';
import { NgxPageScrollModule } from 'ngx-page-scroll';

import { Advertise1Component } from './advertise1/advertise1.component';
import { Advertise2Component } from './advertise2/advertise2.component';
import { AdvertiseComponent } from './advertise/advertise.component';
import { CartpageComponent } from './cartpage/cartpage.component';
import { CartitemComponent } from './cartitem/cartitem.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { CartverifyComponent } from './cartverify/cartverify.component';
import { DetailsComponent } from './details/details.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { HomepageComponent } from './homepage/homepage.component';
import { InteractionService } from './interaction.service';
import { LoginComponent } from './login/login.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PaymentpayComponent } from './paymentpay/paymentpay.component';
import { ProductcatalogueComponent } from './productcatalogue/productcatalogue.component';
import { ProfileComponent } from './profile/profile.component';
import { RegistrationComponent } from './registration/registration.component';
import { SelectcityComponent } from './selectcity/selectcity.component';
import { ViewproductComponent } from './viewproduct/viewproduct.component';

import { AddressComponent } from './home/address/address.component';
import { LogoutComponent } from './home/logout/logout.component';
import { NotificationComponent } from './home/notification/notification.component';
import { OrderComponent } from './home/order/order.component';
import { PancardComponent } from './home/pancard/pancard.component';
import { PaymentComponent } from './home/payment/payment.component';
import { RewardComponent } from './home/reward/reward.component';


@NgModule({
  declarations: [
    AppComponent,
    // RoutingComponent,
    Advertise1Component,
    Advertise2Component,
    AdvertiseComponent,
    CartpageComponent,
    CartitemComponent,
    CheckoutComponent,
    CartverifyComponent,
    DetailsComponent,
    ForgotpasswordComponent,
    HomepageComponent,
    LoginComponent,
    NavBarComponent,
    NavbarComponent,
    PaymentpayComponent,
    ProductcatalogueComponent,
    ProfileComponent,
    RegistrationComponent,
    SelectcityComponent,
    ViewproductComponent,

    AddressComponent,
    LogoutComponent,
    NotificationComponent,
    OrderComponent,
    PancardComponent,
    PaymentComponent,
    RewardComponent

  ],
  imports: [
    BrowserModule,
    RouterModule,
    AppRoutingModule,
    NgxImageZoomModule,
    NgxPageScrollModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [InteractionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
