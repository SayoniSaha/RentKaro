import { Component, OnInit } from '@angular/core';
import { Router, Route } from '@angular/router';
import { InteractionService } from '../interaction.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  message: accountInfo | undefined;
  constructor(private router: Router, private interactionService: InteractionService) { }

  email: string | undefined;
  password: string | undefined;
  userId: string | undefined;
  error: string | undefined;
  url: string | undefined;
  urlnew: string | undefined;
  cid: string | undefined;
  city: string | undefined;

  ngOnInit() {

  }

  login(): void {

    //checking if someone has already logged in or in 
    this.userId = localStorage.getItem('token')!;
    // this.city = localStorage.getItem('city');
    this.city = localStorage.getItem('city')!;
    this.router.navigate(['homepage/' + this.city]);
    if (this.userId == undefined) {    //if no-one has logged in then only calling the fetch api for log in the user onto our website 
      this.url = `http://localhost:8888/login`;

      const loginData = {
        email: this.email,
        password: this.password,
      };

      console.log("Email:", this.email);
      console.log("Password:", this.password);
      fetch(this.url, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          'Accept': 'application/json'
        },
        body: JSON.stringify(loginData)
      })
        .then(res => res.text())
        .then(data => {
          if (data == "Wrong Credentials") {
            this.error = "wrong credentials"
            alert(this.error);
            let city = localStorage.getItem('city');
            this.router.navigate(['homepage/' + city]);
          }
          else {
            alert("Successfully Logged in!")
            let city = localStorage.getItem('city');
            this.router.navigate(['homepage/' + city]);
            console.log(data);

            this.cid = this.email;
            // this.cid = localStorage.getItem('token')!;
            this.url = `http://localhost:8888/findcustomer/` + this.cid;
            fetch(this.url)
              .then(res => res.json())
              .then(data => {
                if (data.length > 0 && data[0].hasOwnProperty('customer_email')) {
                  this.userId = data[0].customer_id;
                  localStorage.setItem('id', this.userId!);
                  console.log(data);
                  console.log("hello");
                  this.message = data[0];
                  this.interactionService.sendMessage(this.message!);
                  window.location.reload();
                } else {
                  console.error('Invalid response data:', data);
                }
              })
            localStorage.setItem('token', data)
            localStorage.setItem('city', this.city!);
          }

        })
    } else { //if user has already logged in then he will not be able to log once again 
      this.error = "User already logged in, logout first!"
      this.router.navigate(['home']);
    }
  }
}


//creating the interface that we have to send
interface accountInfo {
  customer_address: any,
  customer_contact: any,
  customer_email: any,
  customer_gender: any,
  customer_id: any,
  customer_name: any,
  customer_password: any,
  customer_wallet: any,
  id: any,
}
