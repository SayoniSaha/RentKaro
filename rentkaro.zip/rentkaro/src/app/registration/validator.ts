import { AbstractControl } from '@angular/forms';

export function passValidator(control:AbstractControl){

}