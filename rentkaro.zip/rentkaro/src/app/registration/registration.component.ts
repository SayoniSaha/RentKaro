import { Component, OnInit, ViewChild, ElementRef, NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, NgForm } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {
  @ViewChild('openModal', { static: false }) openModal!: ElementRef;
  signupform!: FormGroup;

  fname: String | undefined
  lname: String | undefined
  email: String | undefined
  password: String | undefined
  confirmPass: String | undefined
  phonenumber: String | undefined
  address: String | undefined;
  gender: String | undefined;
  _url1:any;
  error: any;
  url: any;
 
  


  constructor(private router: Router, private formbuilder: FormBuilder) {
    this.signupform = formbuilder.group({
      fname: ['', [Validators.required, Validators.minLength(3),Validators.pattern('[a-zA-Z ]*')]],
      lname: [''],
      email: ['', [Validators.required,Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.com$')]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPass: ['', Validators.required],
      phonenumber: ['',[ Validators.required,Validators.pattern('^[7-9][0-9]{9}$')]],
      address: ['', Validators.required],
      gender: ['', Validators.required],
     
    },
      { validator: this.MustMatch('password', 'confirmPass') });
  }



  ngOnInit() {
    this.openModal.nativeElement.click();
  }
  postData(signupform: any) {
    alert("Successfully registered!")
    console.log('Form Values:', this.signupform.value);
    let city = localStorage.getItem('city');
    this.router.navigate(['homepage/' + city]);
    
    this.url = `http://localhost:8888/register`
    this.fname = signupform.controls.fname.value;
    this.lname = signupform.controls.lname.value;
    this.email = signupform.controls.email.value;
    this.confirmPass = signupform.controls.confirmPass.value;
    this.password = signupform.controls.password.value;
    this.gender = signupform.controls.gender.value;
    this.address = signupform.controls.address.value;
    this.phonenumber = signupform.controls.phonenumber.value;

    const formData = {
      customer_name: this.fname + " " + this.lname,
      customer_email: this.email,
      customer_password: this.password,
      customer_contact: this.phonenumber,
      customer_gender: this.gender,
      customer_address: this.address,
      customer_wallet: 1000
    };
  
    console.log('Form Data:', formData);
  

    fetch(this.url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        'Accept': 'application/json'
      },
      body: JSON.stringify(formData)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log(data);
    })
    .catch(error => {
      console.error('There was a problem with the fetch operation:', error);
    });
  }
  
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors['mustMatch']) {
        return;
      }

      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    }
  }
}
