import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertise1',
  templateUrl: './advertise1.component.html',
  styleUrls: ['./advertise1.component.css']
})
export class Advertise1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
