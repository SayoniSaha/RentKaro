import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InteractionService {

  private _accountInfoSource = new BehaviorSubject<accountInfo>({
    customer_address: null,
    customer_contact: null,
    customer_email: null,
    customer_gender: null,
    customer_id: null,
    customer_name: null,
    customer_password: null,
    customer_wallet: null,
    id: null,
  });
  public accountInfo$ = this._accountInfoSource.asObservable();
  constructor() { }

  sendMessage(message: accountInfo) {
    this._accountInfoSource.next(message);
    console.log(message)
    console.log("interaction message")
  }
}


interface accountInfo {
  customer_address: any,
  customer_contact: any,
  customer_email: any,
  customer_gender: any,
  customer_id: any,
  customer_name: any,
  customer_password: any,
  customer_wallet: any,
  id: any,
}
