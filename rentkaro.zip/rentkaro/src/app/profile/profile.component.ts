import { InteractionService } from './../interaction.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, NgForm, ControlContainer } from '@angular/forms';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  signupform!: FormGroup;

  name: string | undefined;
  gender: string | undefined;
  number: string | undefined
  email: string | undefined;
  cid: string | undefined;
  url: string | undefined;


  city: any;
  username: string | undefined;
  password: string | undefined;
  userId: string | undefined;
  error: string | undefined;
  urlnew: string | undefined;
  cart: string | undefined;

  constructor(private interactionService: InteractionService, private formbuilder: FormBuilder) {

  }

  ngOnInit() {

    this.city = localStorage.getItem("city");
    console.log("mycity" + this.city)
    this.city = localStorage.getItem('city');
    let url = "http://localhost:8888/showallproduct?city=" + this.city;
    fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data)
      })

    this.cid = localStorage.getItem('id')!;
    if (this.cid != undefined) {
      this.urlnew = 'http://localhost:8888/findcustomerid/' + this.cid;
      fetch(this.urlnew)
        .then(res => res.json())
        .then(data => {
          this.username = data[0].customername;
          this.city = localStorage.getItem("city");
        })
    }
    else {
      this.username = 'noLoggedInUser'
    }

    let url3 = "http://localhost:8888/viewcart/" + this.cid;
    fetch(url3, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data);
        if (data[0] != null) {
          this.cart = 'items';
        }
        else {
          this.cart = 'noitems';
        }
      })
    //********************* */

    this.cid = localStorage.getItem('id')!;
    this.url = `http://localhost:8888/findcustomerid/` + this.cid;
    fetch(this.url)
      .then(res => res.json())
      .then(data => {
        console.log("mydata");
        console.log(data);
        (<HTMLOutputElement>document.getElementById('name')).value = data[0].customername;
        (<HTMLOutputElement>document.getElementById('gender')).value = data[0].customergender;
        (<HTMLOutputElement>document.getElementById('contact')).value = data[0].customercontact;
        (<HTMLOutputElement>document.getElementById('mail')).value = data[0].customeremail;
      })

  }

  logout() {
    alert("You have logged out from this session!");
    localStorage.removeItem('token');
    localStorage.removeItem('id');
    window.location.reload();
  }
}
