import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pancard',
  templateUrl: './pancard.component.html',
  styleUrls: ['./pancard.component.css']
})
export class PancardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
