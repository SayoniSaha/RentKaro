import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, FormBuilder, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-paymentpay',
  templateUrl: './paymentpay.component.html',
  styleUrls: ['./paymentpay.component.css']
})
export class PaymentpayComponent implements OnInit {

  signupform: FormGroup | undefined;

  productinfo: String | undefined
  firstname: String | undefined
  email: String | undefined
  phone: String | undefined
  amount: String | undefined
  _url: any;
  _url1: any;
  error: any;


  public payuform: any = {};
  disablePaymentButton: boolean = true;
  finalAmount: any;
  cid: string | undefined;
  url: string | undefined;

  constructor(private http: HttpClient, private router: Router) { }

  confirmPayment() {

    const paymentPayload = {
      email: this.payuform.email,
      name: this.payuform.firstname,
      phone: this.payuform.phone,
      productInfo: this.payuform.productinfo,
      amount: this.payuform.amount
    }
    return this.http.post<any>('http://localhost:8885/payment/payment-details', paymentPayload).subscribe(
      data => {
        console.log(data);
        this.payuform.txnid = data.txnId;
        this.payuform.surl = data.sUrl;
        this.payuform.furl = data.fUrl;
        this.payuform.key = data.key;
        this.payuform.hash = data.hash;
        this.payuform.txnid = data.txnId;
        this.disablePaymentButton = false;
        localStorage.removeItem('products')
        localStorage.removeItem('finalAmount')
      },
      error1 => {
        console.log(error1);
      })
  }

  placeOrder() {
    return this.http.get('http://localhost:8888/checkout/success/' + this.cid).subscribe(
      data => {
        alert("Payment Successful!")
        console.log("Cart deleted!")
        this.router.navigate(['cartpage/']);
      })
  }



  ngOnInit() {

    this.finalAmount = localStorage.getItem('finalAmount');
    console.log(this.finalAmount);
    (<HTMLOutputElement>document.getElementById("amount")).value = this.finalAmount;
    this.payuform.amount = this.finalAmount;

    this.cid = localStorage.getItem('id')!;
    this.url = `http://localhost:8888/findcustomerid/` + this.cid;
    fetch(this.url)
      .then(res => res.json())
      .then(data => {
        (<HTMLOutputElement>document.getElementById('firstname')).value = data[0].customer_address;
        this.payuform.firstname = data[0].customeraddress;
        (<HTMLOutputElement>document.getElementById('productInfo')).value = data[0].customer_name;
        this.payuform.productinfo = data[0].customername;
        (<HTMLOutputElement>document.getElementById('email')).value = data[0].customer_email;
        this.payuform.email = data[0].customeremail;
        (<HTMLOutputElement>document.getElementById('phone')).value = data[0].customer_contact;
        this.payuform.phone = data[0].customercontact;
      })

  }

}
