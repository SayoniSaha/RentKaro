import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-cartitem',
  templateUrl: './cartitem.component.html',
  styleUrls: ['./cartitem.component.css']
})
export class CartitemComponent implements OnInit {
  cid: any
  pid: any
  List: any
  List2: any
  List3: any
  List4: any[] = [];
  List5: any[] = [];
  List6: any[] = [];
  List7: any[] = [];
  address: any;
  amount: any;
  data: number | undefined;
  plusval: any;
  quantity: any;
  url: string | undefined;
  period: any;
  plusval2: any;
  productname: any;
  finalAmount: any;
  product_id: string | undefined;
  subtotal: number = 0;
  constructor(private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.quantity = 1;
    this.period = 1;
    this.cid = localStorage.getItem('id');
    console.log(this.cid + " is the customer id");

    let url3 = "http://localhost:8888/viewcart/" + this.cid;

    fetch(url3, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    }).then(res => res.json())
      .then(data => {
        console.log(data);
        this.List = data;
        console.log(this.List);
        setTimeout(() => {
          var sum = 0;
          for (let i of data) {
            let product_id = i.product_id;
            console.log("Trying to access element with ID: " + "input" + product_id);
            // let quantityElement = document.getElementById("input" + product_id) as HTMLInputElement;
            // console.log("Found element: " + quantityElement);
            let quantity = 1;
            console.log("Quantity value: " + quantity);


            // Fetch product_price from product table using product_id
            let productUrl = `http://localhost:8888/showproductbyid/${product_id}`;
            fetch(productUrl, {
              method: "GET",
              headers: {
                "content-type": "application/json"
              }
            })
              .then((res: Response) => res.json())
              .then(productData => {
                console.log(productData);
                let product_price = productData[0].product_price;
                console.log(product_price);
                let subtotal = product_price * quantity * this.period;
                // let subtotElement = document.getElementById("subtotal" + product_id) as HTMLOutputElement;
  
                // if (subtotElement) {
                //   console.log(subtotal);
                //   console.log(subtotElement);
                //   subtotElement.innerText = String(subtotal);
                // }
                // console.log("subtotal" + product_id);
                // console.log(subtotal);
                // console.log(subtotElement);
                // subtotElement.innerText = String(subtotal);

                sum = sum + subtotal;
                (<HTMLOutputElement>document.getElementById('amount')).innerHTML = String(sum);
                this.finalAmount = sum + 50;
                (<HTMLOutputElement>document.getElementById('finalamount')).innerHTML = String(this.finalAmount);
                localStorage.setItem('finalAmount', this.finalAmount);
              });
          }

        }, 1000)


      })

    let url4 = `http://localhost:8888/findcustomerid/` + this.cid;
    fetch(url4, {
      method: "GET",
      headers: {
        "content-type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        console.log(data);
        this.address = data[0].customeraddress;
      })

    //let url5=`http://b8java18.iiht.tech:3000/showproductbyid/p1`;

    this.List3 = JSON.parse(localStorage.getItem('products')!);
    console.log(this.List3);
    for (var i of this.List3) {

      this.pid = i.product_id;
      this.List5.push(this.pid);
      console.log(this.List5);
    }

    ///////////////////////


    for (var i of this.List5) {
      console.log(i);
      let url5 = `http://localhost:8888/showproductbyid/` + i
      fetch(url5, {
        method: "GET",
        headers: {
          "content-type": "application/json"
        }
      }).then((res: Response) => res.json())
        .then(data => {
          this.List2 = data;
          console.log(this.List2);

          this.List4.push(this.List2);
          console.log(this.List4);
        })

    }
    this.List6 = this.List4;
    console.log(this.List6);


  }





  plus(id: any) {
    console.log(id);
    let elementid = "input" + id;
    console.log(elementid);
    this.plusval = +((<HTMLInputElement>document.getElementById(elementid)).value);
    console.log(this.plusval);
    var price = "price" + id;
    var subtotal = +((<HTMLInputElement>document.getElementById(price)).innerHTML);
    this.quantity = this.plusval + 1;
    (<HTMLOutputElement>document.getElementById(elementid)).value = String(this.quantity);
    console.log(subtotal * this.quantity * this.period);
    let subtot = "subtotal" + id;
    (<HTMLOutputElement>document.getElementById(subtot)).innerHTML = String(this.quantity * subtotal * this.period);
    var sum = 0;
    for (let i of this.List) {
      let id = "subtotal" + i.product_id;
      console.log(id);
      var p = +(<HTMLInputElement>document.getElementById(id)).innerText;
      sum = sum + p;
    }
    (<HTMLOutputElement>document.getElementById('amount')).innerHTML = String(sum);
    (<HTMLOutputElement>document.getElementById('finalamount')).innerHTML = String(sum + 50);
  }

  minus(id: any) {
    console.log(id);
    let elementid = "input" + id;
    this.plusval = +((<HTMLInputElement>document.getElementById(elementid)).value);
    var price = "price" + id;
    var subtotal = +((<HTMLInputElement>document.getElementById(price)).innerHTML);
    if (this.plusval > 1) {
      this.quantity = this.plusval - 1;
      (<HTMLOutputElement>document.getElementById(elementid)).value = String(this.quantity);
      console.log(subtotal * this.quantity * this.period);
      let subtot = "subtotal" + id;
      (<HTMLOutputElement>document.getElementById(subtot)).innerHTML = String(this.quantity * subtotal * this.period);
      var sum = 0;
      for (let i of this.List) {
        let id = "subtotal" + i.product_id;
        console.log(id);
        var p = +(<HTMLInputElement>document.getElementById(id)).innerText;
        sum = sum + p;
      }
      (<HTMLOutputElement>document.getElementById('amount')).innerHTML = String(sum);
      (<HTMLOutputElement>document.getElementById('finalamount')).innerHTML = String(sum + 50);
    }

  }

  deleteitem(pid: String) {
    let url = "http://localhost:8888/deleteitem/" + pid + "/" + this.cid;
    fetch(url, {
      method: "DELETE"
    })

    window.location.reload();
    var storedArray = JSON.parse(localStorage.getItem('products')!);
    console.log(storedArray);
    for (var i of storedArray) {

      var id = i.product_id;
      this.List7.push(id);
      console.log(this.List7);
    }
    for (i = 0; i < this.List7.length; i++) {
      if (this.List7[i] == pid) {
        this.List7.splice(i, 1);
        console.log(this.List7);
      }
    }
    let products = [];
    localStorage.removeItem('products');
    for (i = 0; i < this.List7.length; i++) {
      if (localStorage.getItem('products')) {
        products = JSON.parse(localStorage.getItem('products')!);
      }
      products.push({ 'product_id': this.List7[i] });
      localStorage.setItem('products', JSON.stringify(products));

    }
  }

  addmore() {
    console.log("addmore");
    let city = localStorage.getItem('city');
    this.router.navigate(['homepage/' + city]);
  }

  checkout() {
    let status: any
    for (let i of this.List) {
      let product_id = i.product_id;
      console.log("heyaa" + product_id);
      let quantity = 1;
      console.log(quantity + " " + product_id);
      let url = "http://localhost:8888/savecart/" + this.cid + "/" + product_id + "/" + quantity;
      fetch(url, {
        method: "GET",
        headers: {
          "content-type": "application/json"
        }
      }).then(res => res.text()).then(data => {
        console.log(data);
        if (data == "unsuccessfull") {
          status = "unsuccessfull";
        };
      })

    }

    setTimeout(() => {
      console.log(status);
      if (status == "unsuccessfull") {
        alert("Not enough quantity in stock. Reduce the quantity");
      }
      else {
        let finalamount = (<HTMLOutputElement>document.getElementById('finalamount')).innerText;
        localStorage.setItem('amount', finalamount);
        this.router.navigate(['cartverify']);
      }
    }, 1000)


  }


  timeplus(id: any) {

    console.log(id);
    let elementid = "period" + id;
    console.log(elementid);
    this.plusval2 = +((<HTMLInputElement>document.getElementById(elementid)).value);
    console.log(this.quantity + " " + this.plusval2);
    var price = "price" + id;
    var subtotal = +((<HTMLInputElement>document.getElementById(price)).innerHTML);

    if (this.plusval2 <= 6) {
      this.period = this.plusval2 + 1;
      (<HTMLOutputElement>document.getElementById(elementid)).value = String(this.period);
      console.log(subtotal + " " + this.quantity + " " + this.period);
      let subtot = "subtotal" + id;
      (<HTMLOutputElement>document.getElementById(subtot)).innerHTML = String(this.quantity * subtotal * this.period);
      var sum = 0;
      for (let i of this.List) {
        let id = "subtotal" + i.product_id;
        console.log(id);
        var p = +(<HTMLInputElement>document.getElementById(id)).innerText;
        sum = sum + p;
      }
      (<HTMLOutputElement>document.getElementById('amount')).innerHTML = String(sum);
      (<HTMLOutputElement>document.getElementById('finalamount')).innerHTML = String(sum + 50);
    }
  }


  timeminus(id: any) {
    console.log(id);
    let elementid = "period" + id;
    this.plusval2 = +((<HTMLInputElement>document.getElementById(elementid)).value);
    var price = "price" + id;
    var subtotal = +((<HTMLInputElement>document.getElementById(price)).innerHTML);
    if (this.plusval2 > 1) {
      this.period = this.plusval2 - 1;
      (<HTMLOutputElement>document.getElementById(elementid)).value = String(this.period);
      console.log(subtotal * this.quantity * this.period);
      let subtot = "subtotal" + id;
      (<HTMLOutputElement>document.getElementById(subtot)).innerHTML = String(this.quantity * subtotal * this.period);
      var sum = 0;
      for (let i of this.List) {
        let id = "subtotal" + i.product_id;
        console.log(id);
        var p = +(<HTMLInputElement>document.getElementById(id)).innerText;
        sum = sum + p;
      }
      (<HTMLOutputElement>document.getElementById('amount')).innerHTML = String(sum);
      (<HTMLOutputElement>document.getElementById('finalamount')).innerHTML = String(sum + 50);
    }
  }

}
